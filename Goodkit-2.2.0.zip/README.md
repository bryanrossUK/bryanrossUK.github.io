# GOODKIT

Goodkit Theme by Good Themes.

### Documentation

Development documentation is available at `src/html/docs/index.html` (or `dist/docs/index.html` once you've compiled), or visit http://goodkit.goodthemes.co/docs/index.html.

### Getting Started

The steps to compile and get started with development are covered in detail in documentation mentioned above, but the summary is:

- npm install
- npm start

### Design Files

We provide an "unofficial" Goodkit Figma file for you to play with. Learn more about it at http://goodkit.goodthemes.co/docs/figma.html and view/download it here: https://www.figma.com/file/ze96JOh882MgkvWw0HdUqR/Goodkit-v1.1-Distributed?node-id=353%3A281.

### Support

Good Themes is happy to provide support for issues. Shoot us an email at support@goodthemes.co and we'll get you squared away.
